# Auto2FA - Robust SSH Authentication System

## Quick Start

### 1. Setup
```bash
./setup.sh
```

### 2. Configure
- SSH config: `~/.ssh/config`
- Passwords: `~/.ssh/passwords.json`

### 3. Run
```bash
python3 auto2fa.py
```
This will automatically launch the live monitor after login. Use `--no-monitor` if you prefer the classic text mode.
> Tip: pass `--host <name>` (e.g. `python3 auto2fa.py --host Kempner`) to skip the interactive host picker.

### 4. Check Logs (Optional)
```bash
tail -f /tmp/auto2fa.log
```

### 5. (Optional) Launch Monitor Only
```bash
python3 auto2fa.py --monitor-only --host <your-host>
```

This colorful dashboard (powered by `rich`) shows:
- Auto2FA process status and control-master health
- Whether `~/.ssh/config` / `passwords.json` contain the selected host
- The live control socket path and fresh log tail

Example:
```bash
python3 auto2fa.py --monitor-only --host Kempner
```

## What's Fixed

✅ **Mac sleep/wake cycles** - Auto reconnects  
✅ **Long idle periods** - Keeps connections alive  
✅ **Network switching** - Handles WiFi changes  
✅ **Connection timeouts** - Smart retry with backoff  
✅ **2FA expiration** - Fresh codes for each attempt  

## Key Features

- **Smart Reconnection**: Handles all common failure scenarios
- **Fresh OTP**: Generates new 2FA codes for each retry
- **Network Detection**: Tests connectivity before connecting  
- **Comprehensive Logging**: Full audit trail in `/tmp/auto2fa.log`
- **Zero Maintenance**: Set it and forget it
- **VSCode Friendly**: Spawns a persistent SSH control master so Remote-SSH can reuse the session with no extra prompts

## VS Code Remote-SSH

When the script connects it prints the path of the shared SSH control socket (for example `~/.ssh/auto2fa_control/myserver_a1b2c3d4.sock`). Make sure the matching host block in your `~/.ssh/config` reuses the same socket so tools like VS Code Remote-SSH skip additional 2FA prompts:

```
Host myserver
    HostName server.example.com
    User myusername
    ControlMaster auto
    ControlPersist 10m
    ControlPath ~/.ssh/auto2fa_control/myserver_a1b2c3d4.sock
```

VS Code Remote-SSH automatically honours these options. After the socket exists, connecting from VS Code will attach instantly without requesting a new 2FA code.

## Troubleshooting

- **Check logs**: `tail -f /tmp/auto2fa.log`
- **All issues auto-resolve**: The system handles reconnections automatically

Now you can close your Mac, switch networks, or leave it idle - connections stay reliable!