# Auto2FA - 超强SSH自动登录系统

## 🚀 快速使用指南

### 1. 安装依赖
```bash
./setup.sh
```

### 2. 配置文件设置

#### SSH配置文件 (`~/.ssh/config`)
```
Host myserver
    HostName server.example.com
    User myusername
    Port 22
```

#### 密码配置文件 (`~/.ssh/passwords.json`)
```json
{
  "myserver": {
    "password": "你的密码",
    "otpauthUrl": "otpauth://totp/Example:user@example.com?secret=你的2FA密钥&issuer=Example"
  }
}
```

**注意**: Host名称（如"myserver"）必须在两个文件中保持一致！

### 3. 启动自动登录
```bash
python3 auto2fa.py
```
脚本会在成功登录后自动打开动态监控面板；如需传统模式，可加 `--no-monitor` 禁用。
> 小提示：可以加上 `--host <名称>`（如 `python3 auto2fa.py --host Kempner`）直接跳过交互式选择。

选择对应的服务器编号，系统会自动处理密码和2FA验证码输入。

### 4. 查看日志（可选）
```bash
tail -f /tmp/auto2fa.log
```

### 5. （可选）仅启动监控面板
```bash
python3 auto2fa.py --monitor-only --host <你的Host名称>
```

该面板基于 `rich`，可以实时查看：
- Auto2FA 进程和 ControlMaster 状态
- `~/.ssh/config`、`passwords.json` 中是否存在对应主机配置
- 控制 socket 路径以及最新日志

示例：
```bash
python3 auto2fa.py --monitor-only --host Kempner
```

## ✨ 主要改进

这个增强版本解决了所有常见的连接问题：

### 🔧 **超强稳定性**
- ✅ **Mac合盖/唤醒** - 自动检测并重连
- ✅ **长时间不操作** - 每30秒保活，5分钟强制刷新连接
- ✅ **网络切换** - WiFi切换时自动重连
- ✅ **连接超时** - 智能重试，指数退避算法
- ✅ **2FA过期** - 每次重连生成新的验证码

### 📊 **智能监控**
- 实时日志记录到 `/tmp/auto2fa.log`
- 网络连接状态检测
- 连接失败自动诊断
- 多种重试策略

### 🛡️ **安全特性**
- 每次重试生成新的2FA验证码
- 安全的凭据处理
- 日志中不记录敏感信息
- VSCode 友好：自动创建 SSH ControlMaster，VS Code Remote-SSH 可直接复用会话无需再次认证

## 💻 VS Code Remote-SSH 配置

程序连上服务器后会输出一个共享的 SSH 控制通道路径（例如 `~/.ssh/auto2fa_control/myserver_a1b2c3d4.sock`）。请在对应的 `~/.ssh/config` 主机配置中引用同一个路径，这样 VS Code Remote-SSH 就能直接复用连接，无需再次输入密码或 2FA：

```
Host myserver
  HostName server.example.com
  User myusername
  ControlMaster auto
  ControlPersist 10m
  ControlPath ~/.ssh/auto2fa_control/myserver_a1b2c3d4.sock
```

VS Code 会自动读取这些设置。控制通道建立后，从 VS Code 连接服务器将瞬间成功且不会再次弹出 2FA 验证。

## 🎯 **实际使用场景**

### 场景1：日常工作
```bash
# 启动后选择服务器，系统会自动维护连接
python3 auto2fa.py
# 选择服务器编号，然后放心使用，系统会处理所有断线重连
```

### 场景2：Mac合盖后使用
- 合盖前：连接正常运行
- 合盖后：系统自动检测网络变化
- 打开后：自动重新连接，无需手动操作

### 场景3：网络切换
- WiFi切换：自动检测并重连
- 网络中断：等待网络恢复后重连
- VPN切换：智能处理网络变化

## 📋 **故障排除**

### 查看详细日志
```bash
tail -f /tmp/auto2fa.log
```

### 常见问题

**Q: 连接经常断开？**
A: 系统会自动重连，终端会显示重连状态

**Q: 2FA验证失败？**
A: 系统会生成新的验证码重试，确保系统时间同步正确

**Q: 网络切换后无法连接？**
A: 系统会自动检测网络变化并重新连接

## 📁 **文件说明**

- `auto2fa.py` - 主程序（增强版）
- `setup.sh` - 自动安装依赖脚本
- `/tmp/auto2fa.log` - 运行日志
- `old_versions/` - 旧版本文件备份

## 🎉 **就这么简单**

1. **首次使用**：运行 `./setup.sh` 检查环境
2. **日常使用**：直接运行 `python3 auto2fa.py`
3. **出现问题**：查看 `tail -f /tmp/auto2fa.log`

现在你可以放心地使用SSH连接，不用担心Mac合盖、网络切换或长时间不操作导致的连接问题！